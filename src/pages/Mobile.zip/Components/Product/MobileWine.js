import React from 'react'
import Style from './css/MobileWine.module.css'

export default function MobileWine() {
  return (
    <div>MobileWine</div>
  )
}
